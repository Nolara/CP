import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
